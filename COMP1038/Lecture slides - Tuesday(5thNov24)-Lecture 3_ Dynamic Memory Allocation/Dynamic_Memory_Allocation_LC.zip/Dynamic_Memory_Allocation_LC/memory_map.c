#include<stdio.h>

int global = 1;

int main(void)
{  
   static int i = 100;
   return(0);
}
