#include<stdio.h>
#include<stdlib.h>

int global;

int main(void)
{  
   static int i = 100;
   static int j;

   int k;

   int *p = malloc(sizeof(int));

   printf("%p\n", &k);
   printf("%p\n", &p);
   printf("%p\n", &j);
   printf("%p\n", &global);
   printf("%p\n", &i);
   printf("%p\n", main);
   return(0);
}
