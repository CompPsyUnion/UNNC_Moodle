#include<stdio.h>

int global;

int main(void)
{  
   static int i = 100;
   static int j;

   int k;

   printf("%p\n", &k);
   printf("%p\n", &j);
   printf("%p\n", &global);
   printf("%p\n", &i);
   printf("%p\n", main);
   return(0);
}
