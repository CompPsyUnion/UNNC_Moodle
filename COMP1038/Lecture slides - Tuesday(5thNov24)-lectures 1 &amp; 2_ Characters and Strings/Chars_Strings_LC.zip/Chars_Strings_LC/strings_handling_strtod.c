#include <stdio.h>
#include <stdlib.h>

int main (){
  char *str1 = "51.2% are admitted";
  char *str2 = "41.5";
  char *str3 = "My number is 1.23 not 4.56";
  char arr[10] = "10.2";

  char *ptr;
  double d;

  d = strtod(str1, &ptr);
  printf("Double value is: %f, and the string is: %s\n", d, ptr);
  
  d = strtod(str2, &ptr);
  printf("Double value is: %f, and the string is: %s\n", d, ptr);
  
  d = strtod(str3, &ptr);
  printf("Double value is: %f, and the string is: %s\n", d, ptr);

  d = strtod(arr, &ptr);
  printf("Double value is: %f, and the string is: %s\n", d, ptr);

  return(0);
}

