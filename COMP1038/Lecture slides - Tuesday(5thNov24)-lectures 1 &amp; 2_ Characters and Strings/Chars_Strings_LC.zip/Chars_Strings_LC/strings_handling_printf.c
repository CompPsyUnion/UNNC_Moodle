#include <stdio.h>

int main(){
  char str[50];
  fgets(str,45,stdin);
  printf("The string is: %s\n", str);
  return(0);
}

