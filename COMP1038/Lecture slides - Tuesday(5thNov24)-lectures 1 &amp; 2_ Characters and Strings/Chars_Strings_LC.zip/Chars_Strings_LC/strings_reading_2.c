#include<stdio.h>

int main(){
  int i, count=0;
  char name[25];
  scanf("%s", name);
  printf("Name = %s\n", name);
  for(i=0;name[i]!='\0';i++)
    if(name[i]=='n')count++;
  printf("Total n's=%d\n", count);
  return(0);
}


