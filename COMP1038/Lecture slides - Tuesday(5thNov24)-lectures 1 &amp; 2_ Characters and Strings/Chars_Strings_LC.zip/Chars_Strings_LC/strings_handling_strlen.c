#include <stdio.h>
#include <string.h>

int main (){
  char str[] = "Nottingham";
  int length = strlen(str);
  printf("Length of string is: %d\n", length);
  return(0);
}

