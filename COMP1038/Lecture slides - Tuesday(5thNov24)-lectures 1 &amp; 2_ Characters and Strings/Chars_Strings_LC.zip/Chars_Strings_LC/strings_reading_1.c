#include<stdio.h>

int main(){
  char name[25];
  scanf("%s", name);
  printf("Name = %s\n", name);
  return(0);
}


