#include <stdio.h>
#include <string.h>

int main (){
  char src[] = "Nottingham";
  char dest[4];
  strncpy(dest, src, 4);
  int len = strlen(dest);
  printf("Copied string: %s\n", dest);
  printf("Length of the destination string: %d\n", len);
  return 0;
}

