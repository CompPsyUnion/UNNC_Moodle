#include <stdio.h>
#include <string.h>

int main (){
  char str1[] = "g f g";
  char str2[] = "g f g";
  int res = strcmp(str1, str2);
  if (res==0)
    printf("Strings are equal");
  else
    printf("Strings are unequal");
  printf("\nValue returned by strcmp() is: %d\n" , res);
  return 0;
}

