#include <stdio.h>
#include <string.h>

int main (){
  char dest[100] = "This is ", src[] = "programiz.com";
  // concatenates src and dest
  // the resultant string is stored in dest.
  strcat(dest, src);
  puts(src);
  puts(dest);
  return 0;
}

