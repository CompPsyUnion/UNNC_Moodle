#include <stdio.h>

int main (){
  char str[] = "University of Nottingham Ningbo China";
  puts("Hello world!");
  puts(str);
  return(0);
}

