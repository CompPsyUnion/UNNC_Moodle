#include <stdio.h>

int main (){
  char str[20] = {'\0'};
  sprintf(str, "Hello World!");
  printf("%s\n", str);

  return(0);
}

