#include <stdio.h>

int main(){
  int day, year;
  char weekday[20], month[20];
  char dtm[100] = "Friday October 29 2021";
  sscanf( dtm, "%s %s %d %d", weekday, month, &day, &year);
  printf( "%s %d, %d = %s\n", month, day, year, weekday);
  return(0);
}

