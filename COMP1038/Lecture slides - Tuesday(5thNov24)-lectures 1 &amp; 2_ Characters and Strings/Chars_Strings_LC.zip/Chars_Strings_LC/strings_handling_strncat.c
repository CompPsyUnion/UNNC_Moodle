#include <stdio.h>
#include <string.h>

int main (){
  char dest[100] = "This is ", src[] = "programiz.com";
  // concatenates src and dest
  // the resultant string is stored in dest.
  strncat(dest, src, 9);
  puts(src);
  puts(dest);
  return 0;
}

