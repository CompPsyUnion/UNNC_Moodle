#include <stdio.h>
#include <string.h>

int main (){
  char str1[15];
  char str2[15];
  int ret;
  strcpy(str1, "abcdef");
  strcpy(str2, "abcdpqrs");
  ret = strncmp(str1, str2, 4);
  if(ret == 0)
    printf("four first characters of str1 are equal to str2\n");
  else
    printf("four first characters of str1 are not equal to str2\n");
  return 0;
}

