#include <stdio.h>

int main(){
  char str[15];
  fgets(str,14,stdin);
  printf("The string is: %s\n", str);
  return(0);
}

