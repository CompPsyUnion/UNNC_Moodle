#include <stdio.h>

int main (){
  char str[20];
  scanf("%s", str);

  printf("%s\n", str);

  return(0);
}

