#include <stdio.h>
#include <stdlib.h>

int main (){
  char *str1 = "51.2% are admitted";
  char *str2 = "41.5";
  char *str3 = "My number is 1.23 not 4.56";
  char arr[10] = "10.2";

  float f = 0.0;

  f = atof("51.2");
  printf("float velue is: %f\n", f);
  
  f = atof(str1);
  printf("float velue is: %f\n", f);

  f = atof(str2);
  printf("float velue is: %f\n", f);

  f = atof(str3);
  printf("float velue is: %f\n", f);

  f = atof(arr);
  printf("float velue is: %f\n", f);

  return(0);
}

