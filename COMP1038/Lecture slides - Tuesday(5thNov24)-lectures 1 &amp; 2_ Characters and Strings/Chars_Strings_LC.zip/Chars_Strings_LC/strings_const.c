#include<stdio.h>

void main(){
char *p = "abc";
printf("%s %s\n",p,p+1);
}


