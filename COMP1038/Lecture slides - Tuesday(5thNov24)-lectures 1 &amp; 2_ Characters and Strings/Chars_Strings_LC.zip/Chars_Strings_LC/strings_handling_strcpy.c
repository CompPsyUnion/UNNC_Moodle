#include <stdio.h>
#include <string.h>

int main (){
  char src[] = "University of Nottingham Ningbo China";
  char dest[100];
  // copying src into dest.
  strcpy(dest, src);
  printf("Copied string: %s\n", dest);
  return 0;
}

