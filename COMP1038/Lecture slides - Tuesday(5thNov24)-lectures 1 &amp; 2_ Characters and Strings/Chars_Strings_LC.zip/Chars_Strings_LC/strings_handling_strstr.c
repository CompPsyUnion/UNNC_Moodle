#include <stdio.h>
#include <string.h>

int main (){
  const char A[20] = "TutorialsPoint.com";
  const char B[10] = "Point";
  char *ret;
  ret = strstr(A, B);
  printf("The matching substring is: %s\n", ret);
  return 0;
}

