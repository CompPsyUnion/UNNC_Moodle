#include<stdio.h>

int main()
{ 
  int i, j;
  scanf("%d%d", &i, &j);
  printf("Sum is: %d", i+j);
}
