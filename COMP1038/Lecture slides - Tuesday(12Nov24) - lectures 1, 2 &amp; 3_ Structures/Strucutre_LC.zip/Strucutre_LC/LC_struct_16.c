#include <stdio.h>

struct Stechno 
{ 
  int comp_id;  
  float sal;
  double id;
};

union Utechno 
{ 
  int comp_id; 
  float sal;
  double id;
};

void main()
{
  struct Stechno stch;
  union Utechno utch;
  
  printf("The size of structure variable: %d\n", sizeof(stch));
  printf("The size of union variable: %d\n\n", sizeof(utch));

}



