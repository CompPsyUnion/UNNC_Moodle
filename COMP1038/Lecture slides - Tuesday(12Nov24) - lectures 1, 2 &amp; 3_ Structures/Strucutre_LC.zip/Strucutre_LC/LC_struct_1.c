#include <stdio.h>

void main( ) 
{ 
    struct book
    {
        char name; 
        float price; 
        int pages; 
    }; 
struct book b[3] ; 
int i;
char c;

for (i = 0; i < 3; i++)
{
    printf ("Enter name, price and pages:  ");
    scanf ("%c %f %d", &b[i].name, &b[i].price, &b[i].pages) ;
    while ((c=getchar()) != '\n' && c != EOF);
}
printf ("\n%c %.1f %d\n\n", b[1].name, b[1].price, b[1].pages);
}
