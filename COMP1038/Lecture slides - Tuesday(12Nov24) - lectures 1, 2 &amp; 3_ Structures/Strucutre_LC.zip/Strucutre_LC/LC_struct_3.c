#include <stdio.h>

void main( ) 
{ 
  struct address
   {
     char phone[15];
     char city[25];
     int pin;
   };

   struct emp
   {
     char name[25];
     struct address a;
   };

struct emp e = { "Peter", "1234567890", "Ningbo", 315100 };

printf("\nname = %s \nphone = %s", e.name, e.a.phone);
printf("\ncity = %s \npin = %d", e.a.city, e.a.pin);
printf("\n\n");
}



