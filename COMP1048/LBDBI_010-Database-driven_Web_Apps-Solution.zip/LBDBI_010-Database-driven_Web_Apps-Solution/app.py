import sqlite3
from flask import Flask, render_template, request, url_for, flash, redirect

app = Flask(__name__)
app.secret_key = "I love DBI"
DATABASE = 'Students.db'

@app.route('/')
def index():
    try:
        conn = sqlite3.connect(DATABASE)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cursor.execute("""
            SELECT 
                sID, 
                firstName, 
                lastName, 
                ROUND(AVG(grade),2) as avgGrade
            FROM Student LEFT JOIN Grade USING (sID)
            GROUP BY sID;
        """)    


        rows = cursor.fetchall()
    except sqlite3.Error as e:
        flash('An error occurred while fetching students.')
        rows = []
    finally:
        conn.close()

    return render_template('index.html', students=rows)

@app.route('/add', methods=['POST'])
def add_student():
    first = request.form.get('firstname', '').strip()
    last = request.form.get('lastname', '').strip()

    if not first:
        flash('First name is required!')
    elif not last:
        flash('Last name is required!')
    else:
        try:
            conn = sqlite3.connect(DATABASE)
            cursor = conn.cursor()
            cursor.execute('INSERT INTO Student (firstName, lastName) VALUES (?, ?)', (first, last))
            conn.commit()
            flash('Student was successfully added!')
        except sqlite3.Error as e:
            flash('An error occurred while adding the student.')
        finally:
            conn.close()
    
    return redirect(url_for('index'))

@app.route('/delete', methods=['POST'])
def delete_student():
    student_id = request.form.get("student-id")
    if not student_id:
        flash('ID is required to delete!')
    else:
        try:
            conn = sqlite3.connect(DATABASE)
            cursor = conn.cursor()
            cursor.execute('DELETE FROM Student WHERE sID = ?', (student_id,))
            conn.commit()
            flash('Student was successfully deleted!')
        except sqlite3.Error as e:
            flash('An error occurred while deleting the student.')
        finally:
            conn.close()

    return redirect(url_for('index'))

@app.route('/modules/', methods=['GET'])
def modules():
    try:
        conn = sqlite3.connect(DATABASE)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cursor.execute("""
            SELECT 
                mCode, 
                title, 
                credits, 
                COUNT(sID) as numStudents, 
                ROUND(AVG(grade),2) as avgGrade
            FROM Module LEFT JOIN Grade USING (mCode)
            GROUP BY mCode
            ORDER BY mCode;
        """)
        rows = cursor.fetchall()
    except sqlite3.Error as e:
        flash('An error occurred while fetching modules.')
        rows = []
    finally:
        conn.close()

    return render_template('modules.html', modules=rows)

@app.route('/modules/add', methods=['POST'])
def add_module():
    mCode = request.form.get('code', '').strip()
    title = request.form.get('title', '').strip()
    credits = request.form.get('credits', '').strip()

    if not mCode:
        flash('Module code is required!')
    elif not title:
        flash('Module title is required!')
    elif not credits:
        flash('Module credits is required!')
    else:
        try:
            conn = sqlite3.connect(DATABASE)
            cursor = conn.cursor()
            cursor.execute('INSERT INTO Module (mCode, title, credits) VALUES (?, ?, ?)', (mCode, title, credits))
            conn.commit()
            flash('Module was successfully added!')
        except sqlite3.Error as e:
            flash('An error occurred while adding the module.')
        finally:
            conn.close()
    
    return redirect(url_for('modules'))

@app.route('/modules/delete', methods=['POST'])
def delete_module():
    module_code = request.form.get("module-code")
    if not module_code:
        flash('Module code is required to delete!')
    else:
        try:
            conn = sqlite3.connect(DATABASE)
            cursor = conn.cursor()
            cursor.execute('DELETE FROM Module WHERE mCode = ?', (module_code,))
            conn.commit()
            flash('Module was successfully deleted!')
        except sqlite3.Error as e:
            flash('An error occurred while deleting the module.')
        finally:
            conn.close()

    return redirect(url_for('modules'))


if __name__ == '__main__':
    app.run(debug=True, port=5000)