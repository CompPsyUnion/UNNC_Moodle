from flask import Flask, render_template, request, flash
app = Flask(__name__)

# Task 1
@app.route("/")
def hello():
	return "Hello World"

# Task 2
# @app.route("/hello/<username>")
# def hello_name(username):
#     return f"Hello {username}"

# Task 3
@app.route("/hello/<username>")
def hello_name(username):
	return render_template('hello.html', name=username)

# Task 7
@app.route("/message/", methods=["GET", "POST"])
def message():
	if request.method == "GET":
		return render_template('message.html')
	else:
		name = request.form.get('name')
		email = request.form.get('email')
		message = request.form.get('message') 
		if name and email and message:
			return render_template('message.html', name=name, email=email, message=message)
		else:
			flash("Please fill out the form completely")
			return render_template('message.html')

if __name__ == "__main__":
   app.secret_key = 'super secret key'
   app.run(debug=True, port=5000)