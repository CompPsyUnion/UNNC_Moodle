from flask import (Flask, url_for, render_template, request)
app = Flask(__name__)

@app.route('/')
def show_form():
    return render_template("form.html")


@app.route('/sayhi/', methods=['GET','POST'])
def sayhi():
    # Note the difference in accessing form values depending
    # on how the information is sent to the server (POST vs GET)
    if request.method == 'GET':
        # We can access the form values several ways
        # request.args is a dictionary-like object
        name = request.args['name']
        # We can also use the get method to access form values. 
        # This is a safer way to access form values as it will not throw an error if the key is not found
        age = age = request.args.get('age')
        # We can also provide a default value if the key is not found
        tel = request.args.get('tel', 'Unknown')
        return '[GET] - {}, {}, and {}'.format(name,age,tel)
    else:
        # We can do similar things with POST requests
        name = request.form['name']
        age = request.form.get('age')
        tel = request.form.get('tel', 'Unknown')
        return '[POST] - {}, {}, and {}'.format(name,age,tel)
    
if __name__ == '__main__':
    app.debug = True
    app.run(port=5000)
