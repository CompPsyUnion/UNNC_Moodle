from flask import Flask, render_template, url_for, redirect, flash
import secrets  # For generating secure secret keys

# Initialise Flask application
app = Flask(__name__)

@app.route('/')
def default():
    # Flash a message and redirect to the module credits page
    flash("You were just redirected!")
    return redirect(url_for('get_modules_credits'))

@app.route('/hello/<name>')
def hello_person(name):
    # Strip - removes any leading/trailing whitespace
    # Capitalize - capitalises the first character
    lname = name.strip().capitalize()
    # Handle invalid input
    if not lname:
        return "Invalid name!", 400
    return render_template("greetings.html", person=lname)

@app.route('/modules/')
def get_modules_credits():
    # A dictionary of module credits (key: module code, value: credits)
    mod_creds = {'DBI': 10, 'PGA': 20, 'FYP': 40}
    return render_template('module_credits.html', result=mod_creds)

@app.route('/inherit')
def inherit():
    # Render a template that demonstrates inheritance
    return render_template("inherit.html")

if __name__ == '__main__':
    app.secret_key = "i love dbi"
    app.run(debug=True, port=5000)

    