# Import the math module for mathematical operations
from math import sqrt
# Import a specific function (getcwd) from the os module
from os import getcwd

# Comments begin with # and are ignored by Python during execution.

# Declare a function using "def", followed by the function name and parameters
def square(x):
    # Return the square of x
    return x * x

# Optional parameters in functions can have default values
def sayHi(a, b="Bob"):
    print("Hello", a, "and hello", b)

# The main entry point for the script
if __name__ == "__main__":
    # Variables in Python are dynamically typed
    a = 0  # Integer
    b = 1.3 # Float
    c = "Hello!" # String
    d = True # Boolean
    e = None # NoneType (absence of a value)
    f = float('1.3') # Convert string to float
    print(type(f)) # Output the type of f

    # Output values using print
    print("hello world")
    print(a, b, c, d, e)

    # If-elif-else conditional
    if a > 0:
        print("Number is positive")
    elif a < 0:
        print("Number is negative")
    else:
        print("Number is 0")

    # Lists: mutable sequences of values
    names = ["Alex", "Bob", "Charlie", "Dan"]
    for name in names:
        print(name)
    print(names[1])  # Access the second element (zero-based index)
    names.append("Evan")  # Add a new element
    names.sort()  # Sort in place
    print(names)

    # Tuples: immutable sequences of values
    point = (12.34, 56.78)
    print(point[0])  # Access the first element

    # Dictionaries: key-value pairs
    population = {"UK": 66796807, "China": 1427647786}
    print(population.get("China"))  # Use .get() to safely access values
    population["Malaysia"] = 31530000  # Add a new key-value pair
    print(population)

    # Loop with range
    for i in range(1, 6):
        print(square(i))

    # Call the function with and without optional parameters
    sayHi("Alex")
    sayHi("Jack", "Jill")

    # Use the math.sqrt() function
    print(sqrt(12345))

    # Use the getcwd() function from the os module
    print(getcwd())