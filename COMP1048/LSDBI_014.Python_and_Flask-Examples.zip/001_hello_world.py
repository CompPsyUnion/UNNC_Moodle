from flask import Flask

# Create a Flask application
app = Flask(__name__)

# Define the root route
@app.route('/')
def hello_world():
    # Return an HTML response
    return '<h1>Hello World!</h1>'

# Define an explicit route that matches "/hello" only
@app.route('/hello')
def hello():
    # Return plain text
    return "Hello"

# Define a route with a trailing slash
@app.route('/world/')
def world():
    # Flask redirects "/world" to "/world/" because of the trailing slash
    return "World"

# Define a dynamic route with a variable in the URL
@app.route('/hello/<name>')
def hello_person(name):
    # Customise the response based on the name
    if name == "Dave":
        name = "Matt"  # Example logic
    # Return a personalised response
    return f"Hello {name}!"

# Entry point for the Flask application
if __name__ == '__main__':
    # Run the app with debugging enabled
    app.run(debug=True, port=5000)